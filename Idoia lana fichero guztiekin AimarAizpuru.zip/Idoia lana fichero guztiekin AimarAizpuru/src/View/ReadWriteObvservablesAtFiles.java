/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controller.GestionLista;
import Model.Coches;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.NotActiveException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.stream.JsonGenerator;
import javax.json.stream.JsonGeneratorFactory;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import jdk.nashorn.internal.parser.JSONParser;
import org.glassfish.json.JsonUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author DM3-2-02
 */
public class ReadWriteObvservablesAtFiles extends Application {

    @Override
    public void start(Stage primaryStage) {

        TableView<Coches> table = new TableView<>();

        Label label = new Label("Autoak");

        final ObservableList<Coches> cars = FXCollections.observableArrayList();
        Coches car = new Coches();

        table.setEditable(true);

        TableColumn<Coches, String> marcaCol = new TableColumn<>("Marca");
        TableColumn<Coches, String> modeloCol = new TableColumn<>("Modelo");
        TableColumn<Coches, String> matriculaCol = new TableColumn<>("Matricula");
        TableColumn<Coches, Number> numDoor = new TableColumn<>("Numero de puertas");
        numDoor.setMinWidth(150);
        TableColumn<Coches, Boolean> fam = new TableColumn<>("Familiar");
        table.getColumns().addAll(marcaCol, modeloCol, matriculaCol, numDoor, fam);

        Button btnLoad = new Button("Kargatu");
        btnLoad.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters()
                    .addAll(
                            new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt"),
                            new FileChooser.ExtensionFilter("XML files (*.xml)", "*.xml"),
                            new FileChooser.ExtensionFilter("JSON files (*.json)", "*.json"));

            File file = fileChooser.showOpenDialog(null);
            if (file != null) {
                String fileName = file.getName();
                String fileExtension = fileName.substring(fileName.lastIndexOf(".") + 1, file.getName().length());
                switch (fileExtension) {
                    case "txt":

                        try {
                            BufferedReader br = new BufferedReader(new FileReader(file));
                            String line;
                            while ((line = br.readLine()) != null) {

                                String[] details = line.split(",");

                                car.setMarca(details[0]);
                                car.setModelo(details[1]);
                                car.setMatricula(details[2]);
                                car.setQuantPuertas(Integer.parseInt(details[3]));
                                car.setFamiliar(Boolean.parseBoolean(details[4]));

                                cars.add(car);
                            }
                            br.close();

                        } catch (FileNotFoundException ex) {
                            JOptionPane.showMessageDialog(null, "Ez da artxiboa aurkitu");
                        } catch (IOException ex) {
                            Logger.getLogger(ReadWriteObvservablesAtFiles.class.getName()).log(Level.SEVERE, null, ex);
                            JOptionPane.showMessageDialog(null, "Errorea irakurtzen");
                        } finally {
                        }

                        break;

                    case "xml":
                        try {
                            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                            DocumentBuilder db = dbf.newDocumentBuilder();
                            Document dc = db.parse(file);

                            NodeList list = dc.getElementsByTagName("Coche");

                            for (int i = 0; i < list.getLength(); i++) {

                                Node node = list.item(i);
                                if (node.getNodeType() == Node.ELEMENT_NODE) {
                                    Element elm = (Element) node;

                                    car.setMarca(elm.getElementsByTagName("marca").item(0).getTextContent());
                                    car.setModelo(elm.getElementsByTagName("modelo").item(0).getTextContent());
                                    car.setMatricula(elm.getElementsByTagName("matricula").item(0).getTextContent());
                                    car.setQuantPuertas(Integer.parseInt(elm.getElementsByTagName("puertasCoches").item(0).getTextContent()));
                                    car.setFamiliar(Boolean.parseBoolean(elm.getElementsByTagName("familiar").item(0).getTextContent()));

                                }
                                cars.add(car);
                            }
                        } catch (ParserConfigurationException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea Irakurtzean");
                        } catch (SAXException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea Irakurtzean");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea Irakurtzean");
                        } finally {
                        }

                        break;
                    case "json": {
                        try {

                            JsonReader reader = Json.createReader(new FileInputStream(file));
                            JsonArray coches = reader.readArray();
                            reader.close();

                            for (int i = 0; i < coches.size(); i++) {
                                JsonObject object = coches.getJsonObject(i);
                                cars.add(new Coches(object.getString("marca"), object.getString("modelo"), object.getString("matricula"), object.getInt("puertasCoches"), object.getBoolean("familiar")));
                            }

                        } catch (FileNotFoundException ex) {
                            JOptionPane.showMessageDialog(null, "Ez da artxiboa aurkitu");
                        } finally {
                        }
                    }

                    break;
                }

            }
        }
        );

        Button btnSave = new Button("Gorde");

        btnSave.setOnAction(e
                -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters()
                    .addAll(
                            new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt"),
                            new FileChooser.ExtensionFilter("XML files (*.xml)", "*.xml"),
                            new FileChooser.ExtensionFilter("JSON files (*.json)", "*.json"));

            File file = fileChooser.showSaveDialog(primaryStage);

            if (file != null) {

                String fileName = file.getName();
                String fileExtension = fileName.substring(fileName.lastIndexOf(".") + 1, file.getName().length());
                switch (fileExtension) {

                    case "txt":
                        try {
                            BufferedWriter bf = new BufferedWriter(new FileWriter(file));
                            for (Coches coche : table.getItems()) {
                                bf.write(coche.escrbirDatos());
                                bf.newLine();
                            }
                            bf.close();

                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea artxiboa idazten");
                        } finally {
                        }
                        break;

                    case "xml":

                        try {
                            int cont = 1;
                            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                            DocumentBuilder db = dbf.newDocumentBuilder();
                            Document dc = db.newDocument();

                            Element grandpaEl = dc.createElement("Coches");
                            dc.appendChild(grandpaEl);

                            for (Coches c : table.getItems()) {

                                Element fatherEl = dc.createElement("Coche");
                                fatherEl.setAttribute("Id", cont + "");
                                grandpaEl.appendChild(fatherEl);

                                Element marca = dc.createElement("marca");
                                marca.appendChild(dc.createTextNode(c.getMarca()));
                                fatherEl.appendChild(marca);

                                Element modelo = dc.createElement("modelo");
                                modelo.appendChild(dc.createTextNode(c.getModelo()));
                                fatherEl.appendChild(modelo);

                                Element matricula = dc.createElement("matricula");
                                matricula.appendChild(dc.createTextNode(c.getMatricula()));
                                fatherEl.appendChild(matricula);

                                Element puertasCant = dc.createElement("puertasCoches");
                                puertasCant.appendChild(dc.createTextNode(c.getQuantPuertas().toString()));
                                fatherEl.appendChild(puertasCant);

                                Element familiar = dc.createElement("familiar");
                                familiar.appendChild(dc.createTextNode(c.getFamiliar().toString()));
                                fatherEl.appendChild(familiar);

                                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                                Transformer transformer = transformerFactory.newTransformer();
                                transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                                DOMSource source = new DOMSource(dc);
                                StreamResult result = new StreamResult(file);

                                // Output to console for testing
                                // StreamResult result = new StreamResult(System.out);
                                transformer.transform(source, result);
                                cont++;

                            }
                        } catch (ParserConfigurationException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea artxiboa idazten");

                        } catch (TransformerConfigurationException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea artxiboa idazten");

                        } catch (TransformerException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea artxiboa idazten");
                        } finally {
                        }
                        break;

                    case "json":

                        try {

                            OutputStream fos = new FileOutputStream(file);
                            JsonGenerator gen = Json.createGenerator(fos);
                            gen.writeStartArray();
                            for (Coches kotxea : table.getItems()) {
                                gen.writeStartObject()
                                        .write("marca", kotxea.getMarca())
                                        .write("modelo", kotxea.getModelo())
                                        .write("matricula", kotxea.getMatricula())
                                        .write("puertasCoches", kotxea.getQuantPuertas())
                                        .write("familiar", kotxea.getFamiliar())
                                        .writeEnd();
                            }
                            gen.writeEnd();
                            gen.close();
                            fos.close();
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(null, "Errorea artxiboa idazten");
                        } finally {
                        }

                        break;
                }
            }
        }
        );
        TextField addMarca = new TextField();
        addMarca.setPromptText("Marca");
        addMarca.setMaxWidth(marcaCol.getPrefWidth());

        TextField addModelo = new TextField();
        addModelo.setMaxWidth(modeloCol.getPrefWidth());
        addModelo.setPromptText("Modelo");
        
        TextField addMatricula = new TextField();
        addMatricula.setMaxWidth(matriculaCol.getPrefWidth());
        addMatricula.setPromptText("Matricula");
        
        TextField addCantPuertas = new TextField();
        addCantPuertas.setMaxWidth(numDoor.getPrefWidth());
        addCantPuertas.setPromptText("Cantidad Puertas");
        addCantPuertas.setMinWidth(150);
        
        TextField addFamiliar = new TextField();
        addFamiliar.setMaxWidth(fam.getPrefWidth());
        addFamiliar.setPromptText("Familiar");

        final Button addButton = new Button("Gehitu");

        addButton.setOnAction(
                (ActionEvent e) -> {
                    try {
                        cars.add(new Coches(addMarca.getText(), addModelo.getText(), addMatricula.getText(), Integer.parseInt(addCantPuertas.getText()), Boolean.parseBoolean(addFamiliar.getText())));
                    } catch (NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(null, "Error datu mota");
                    } finally {
                        addMarca.clear();
                        addModelo.clear();
                        addMatricula.clear();
                        addCantPuertas.clear();
                        addFamiliar.clear();

                    }

                }
        );

        final Button removeButton = new Button("Ezabatu");

        removeButton.setOnAction(
                (ActionEvent e) -> {
                    Coches kotxe = table.getSelectionModel().getSelectedItem();
                    cars.remove(kotxe);
                }
        );

        marcaCol.setCellValueFactory(col -> col.getValue().marcaProperty());
        modeloCol.setCellValueFactory(col -> col.getValue().modeloProperty());
        matriculaCol.setCellValueFactory(col -> col.getValue().matriculaProperty());
        numDoor.setCellValueFactory(col -> col.getValue().quantDoorProperty());
        fam.setCellValueFactory(col -> col.getValue().familiarProperty());
        table.setItems(cars);

        HBox hb = new HBox();

        hb.getChildren().addAll(addMarca, addModelo, addMatricula, addCantPuertas, addFamiliar, addButton, removeButton);
        hb.setSpacing(3);
        VBox rootBox = new VBox();

        rootBox.setSpacing(5);
        rootBox.setPadding(new Insets(10, 10, 10, 10));
        rootBox.getChildren().addAll(label, table, hb, btnLoad, btnSave);
        rootBox.setStyle("-fx-background-color: lightblue ;");
        Scene scene = new Scene(rootBox, 650, 460);

        primaryStage.setTitle("Kotxe desberdinen datuen tabla ");
        primaryStage.setScene(scene);
        label.setFont(new Font("Arial", 20));
        primaryStage.show();
    }

    public static void main(String[] args) throws Exception {
        launch(args);
    }

}
